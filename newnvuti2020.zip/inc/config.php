<?php
require("bd.php");
require("function.php");
?>